import 'package:hive/hive.dart';
part 'decision_map.g.dart';




@HiveType(typeId: 0)
class DecisionMap{

  @HiveField(0)
  late int ID;
  @HiveField(1)
  late int OptionAID;
  @HiveField(2)
  late int OptionBID;
  @HiveField(3)
  late String OptionA;
  @HiveField(4)
  late String OptionB;
  @HiveField(5)
  late String Story;
  @HiveField(6)
  late String Question;

  //DecisionMap(this.Level, this.ID, this.OptionAID, this.OptionBID, this.OptionA, this.OptionB, this.Story, this.Question);

}
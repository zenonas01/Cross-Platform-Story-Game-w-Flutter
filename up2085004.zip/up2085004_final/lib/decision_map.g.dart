// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'decision_map.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class DecisionMapAdapter extends TypeAdapter<DecisionMap> {
  @override
  final int typeId = 0;

  @override
  DecisionMap read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DecisionMap()
      ..ID = fields[0] as int
      ..OptionAID = fields[1] as int
      ..OptionBID = fields[2] as int
      ..OptionA = fields[3] as String
      ..OptionB = fields[4] as String
      ..Story = fields[5] as String
      ..Question = fields[6] as String;
  }

  @override
  void write(BinaryWriter writer, DecisionMap obj) {
    writer
      ..writeByte(7)
      ..writeByte(0)
      ..write(obj.ID)
      ..writeByte(1)
      ..write(obj.OptionAID)
      ..writeByte(2)
      ..write(obj.OptionBID)
      ..writeByte(3)
      ..write(obj.OptionA)
      ..writeByte(4)
      ..write(obj.OptionB)
      ..writeByte(5)
      ..write(obj.Story)
      ..writeByte(6)
      ..write(obj.Question);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DecisionMapAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

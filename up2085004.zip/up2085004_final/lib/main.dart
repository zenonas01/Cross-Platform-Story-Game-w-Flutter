import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'decision_map.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/adapters.dart';


late Box<DecisionMap> box;


Future<void> main() async {

  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();   //HIVE SETUP
  Hive.registerAdapter(DecisionMapAdapter());
  box = await Hive.openBox<DecisionMap>('decisionMap');


  String csv = "assets/data_map.csv"; //path to csv file asset
  String fileData = await rootBundle.loadString(csv);
  print(fileData);
  List <String> rows = fileData.split("\n");
  for (int i = 0; i < rows.length; i++)  {
  //selects an item from row and places
    String row = rows[i];
  //split row into separate items on commas
    List <String> itemInRow = row.split(",");

    DecisionMap decMap = DecisionMap()
      ..ID = int.parse(itemInRow[0])
      ..OptionAID = int.parse(itemInRow[1])
      ..OptionBID = int.parse(itemInRow[2])
      ..OptionA = itemInRow[3]
      ..OptionB = itemInRow[4]
      ..Story = itemInRow[5]
      ..Question = itemInRow[6];

    int key = int.parse(itemInRow[0]);
    box.put(key, decMap);

  }


  runApp (
    const MaterialApp(
      home: MyFlutterApp(),
    ),
  );
}

class MyFlutterApp extends StatefulWidget {
  const MyFlutterApp({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return MyFlutterState();
  }
}


class MyFlutterState extends State<MyFlutterApp> {
  //Flutter UI Widgets go here

  late int ID;
  late int OptionAID;
  late int OptionBID;
  String OptionA = "";
  String OptionB = "";
  String Story = "";
  String Question = "";




  @override
  void initState()  {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() {

        //PLACE CODE HERE YOU WANT TO EXECUTE IMMEDIATELY AFTER
        //THE UI IS BUILT

        DecisionMap? current = box.get(1);
        if(current != null) {
          ID = current.ID;
          OptionAID = current.OptionAID;
          OptionBID = current.OptionBID;
          OptionA = current.OptionA;
          OptionB = current.OptionB;
          Story = current.Story;
          Question = current.Question;
        }


      });
    });
  }


  void clickHandlerA() {
    setState(() {
      DecisionMap? current = box.get(OptionAID);
      if(current != null) {
        ID = current.ID;
        OptionAID = current.OptionAID;
        OptionBID = current.OptionBID;
        OptionA = current.OptionA;
        OptionB = current.OptionB;
        Story = current.Story;
        Question = current.Question;
      }
    });
  }


  void clickHandlerB() {
    setState(() {
      DecisionMap? current = box.get(OptionBID);
      if(current != null) {
        ID = current.ID;
        OptionAID = current.OptionAID;
        OptionBID = current.OptionBID;
        OptionA = current.OptionA;
        OptionB = current.OptionB;
        Story = current.Story;
        Question = current.Question;
      }
    });
  }


  void clickHandlerReset() {
    setState(() {
      DecisionMap? current = box.get(ID);
      if(current != null) {
        ID = 1;
        OptionAID = 2;
        OptionBID = 3;
        OptionA = "Climb to the roof.";
        OptionB = "Run to a lower level.";
        Story = "You are inside your apartment in Tolima City. A police investigation shows that you are the prime suspect in a quadruple homicide. You can see lots of police vehicles coming your way.";
        Question = "What do you choose to do?";
      }
    });
  }





  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffffffff),
      body: Align(
        alignment: Alignment.center,
        child: SizedBox(
          height: MediaQuery
              .of(context)
              .size
              .height,
          width: MediaQuery
              .of(context)
              .size
              .width,
          child: Stack(
            alignment: Alignment.topLeft,
            children: [Image(
              image: AssetImage("assets/images/background.png"),
              height: MediaQuery
                  .of(context)
                  .size
                  .height,
              width: MediaQuery
                  .of(context)
                  .size
                  .width,
              fit: BoxFit.fitHeight,
            ),

              Padding(
                padding: EdgeInsets.fromLTRB(25, 0, 25, 0),
                child: Align(
                  alignment: Alignment(0.0, -1.0),
                  child: Text(
                    "T H E   C H A S E:",
                    textAlign: TextAlign.justify,
                    overflow: TextOverflow.clip,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontStyle: FontStyle.normal,
                      fontSize: 45,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),

              Padding(
                padding: EdgeInsets.fromLTRB(25, 0, 25, 0),
                child: Align(
                  alignment: Alignment(0.0, -0.87),
                  child: Text(
                    "A Quest of Control",
                    textAlign: TextAlign.justify,
                    overflow: TextOverflow.clip,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontStyle: FontStyle.normal,
                      fontSize: 35,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),

              Padding(
                padding: EdgeInsets.fromLTRB(25, 50, 25, 0),
                child: Align(
                  alignment: Alignment(0.0, -0.80),
                  child: Text(
                    Story,
                    textAlign: TextAlign.justify,
                    overflow: TextOverflow.clip,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontStyle: FontStyle.normal,
                      fontSize: 20,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),

              Padding(
                padding: EdgeInsets.fromLTRB(25, 0, 25, 0),
                child: Align(
                  alignment: Alignment(0.0, -0.15),
                  child: Text(
                    Question,
                    textAlign: TextAlign.justify,
                    overflow: TextOverflow.clip,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontStyle: FontStyle.normal,
                      fontSize: 20,
                      color: Color(0xffffffff),

                    ),
                  ),
                ),
              ),
              const Align(
                alignment: Alignment(0.0, 0.2),
                child: Text(
                  "OPTION A:",
                  textAlign: TextAlign.start,
                  overflow: TextOverflow.clip,
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontStyle: FontStyle.normal,
                    fontSize: 20,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(25, 0, 25, 0),
                child:Align(
                  alignment: Alignment(0.0, 0.3),
                  child: Text(
                    OptionA,
                    textAlign: TextAlign.justify,
                    overflow: TextOverflow.clip,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontStyle: FontStyle.normal,
                      fontSize: 20,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
              const Align(
                alignment: Alignment(0.0, 0.45),
                child: Text(
                  "OPTION B:",
                  textAlign: TextAlign.justify,
                  overflow: TextOverflow.clip,
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontStyle: FontStyle.normal,
                    fontSize: 20,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
              Padding(
                  padding: EdgeInsets.fromLTRB(25, 0, 25, 0),
                child:Align(
                alignment: Alignment(0.0, 0.55),
                child: Text(
                  OptionB,
                  textAlign: TextAlign.justify,
                  overflow: TextOverflow.clip,
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontStyle: FontStyle.normal,
                    fontSize: 20,
                    color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
              Align(
                alignment: Alignment(-0.8, 0.77),
                child: MaterialButton(
                  onPressed: () {clickHandlerA();},
                  color: Color(0xff8934eb),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18.0),
                    side: BorderSide(color: Color(0xff808080), width: 1),
                  ),
                  padding: EdgeInsets.all(16),
                  child: Text("OPTION A", style: TextStyle(fontSize: 14,
                    fontWeight: FontWeight.w600,
                    fontStyle: FontStyle.normal,
                  ),),
                  textColor: Color(0xffffffff),
                  height: MediaQuery
                      .of(context)
                      .size
                      .height * 0.05,
                  minWidth: MediaQuery
                      .of(context)
                      .size
                      .width * 0.4,
                ),
              ),
              Align(
                alignment: Alignment(0.8, 0.77),
                child: MaterialButton(
                  onPressed: () {clickHandlerB();},
                  color: Color(0xff8934eb),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18.0),
                    side: BorderSide(color: Color(0xff808080), width: 1),
                  ),
                  padding: EdgeInsets.all(16),
                  child: Text("OPTION B", style: TextStyle(fontSize: 14,
                    fontWeight: FontWeight.w600,
                    fontStyle: FontStyle.normal,
                  ),),
                  textColor: Color(0xffffffff),
                  height: MediaQuery
                      .of(context)
                      .size
                      .height * 0.05,
                  minWidth: MediaQuery
                      .of(context)
                      .size
                      .width * 0.4,
                ),
              ),
              Align(
                alignment: Alignment(0.0, 0.95),
                child: MaterialButton(
                  onPressed: () {clickHandlerReset();},
                  color: Color(0xff393939),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(22.0),
                    side: BorderSide(color: Color(0xff808080), width: 1),
                  ),
                  padding: EdgeInsets.all(16),
                  child: Text("R E S E T", style: TextStyle(fontSize: 25,
                    fontWeight: FontWeight.w600,
                    fontStyle: FontStyle.normal,
                  ),),
                  textColor: Color(0xffd9d9d9),
                  height: MediaQuery
                      .of(context)
                      .size
                      .height * 0.05,
                  minWidth: MediaQuery
                      .of(context)
                      .size
                      .width * 0.9,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}









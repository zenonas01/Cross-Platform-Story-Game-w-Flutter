package com.example.up2085004_final;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
